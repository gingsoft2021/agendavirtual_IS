<script src="<?php echo base_url();?>assets/jquery/jquery-2.2.3.min.js"></script>


<img src="<?php echo base_url();?>assets/img/bienvenido.png">
